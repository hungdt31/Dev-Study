#ifndef MAIN_H
#define MAIN_H
#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<algorithm>
#include<map>
#include<math.h>
#include<vector>
#include<queue>
#include<stack>
#include<list>
using namespace std;
#endif